﻿namespace ODonel_Simple_ROV_Controller
{
    partial class PowerLevelBar
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.powerBar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.powerBar)).BeginInit();
            this.SuspendLayout();
            // 
            // powerBar
            // 
            this.powerBar.BackColor = System.Drawing.SystemColors.Control;
            this.powerBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.powerBar.Location = new System.Drawing.Point(0, 0);
            this.powerBar.Name = "powerBar";
            this.powerBar.Size = new System.Drawing.Size(22, 150);
            this.powerBar.TabIndex = 0;
            this.powerBar.TabStop = false;
            // 
            // PowerLevelBar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.powerBar);
            this.Name = "PowerLevelBar";
            this.Size = new System.Drawing.Size(22, 150);
            ((System.ComponentModel.ISupportInitialize)(this.powerBar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox powerBar;
    }
}
