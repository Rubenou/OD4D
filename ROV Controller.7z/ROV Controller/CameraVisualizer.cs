﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;

namespace ODonel_Simple_ROV_Controller
{
    public class CameraVisualizer
    {
        public static Point[] AToMainSwitchLine()
        {
            //5=y 10=x   to 5=y,45=x   to 25=y,x=45    to 25=y,x=60
            Point a = new Point((int)(Scale * 10), (int)(Scale * 5));
            Point b = new Point((int)(Scale * 45), (int)(Scale * 5));
            Point c = new Point((int)(Scale * 45), (int)(Scale * 25));
            Point d = new Point((int)(Scale * 60), (int)(Scale * 25));
            return new Point[] { a, b, c, d };

        }
        public static Point[] BToAltSwitchLine()
        {
            //25=y 10=x     to 25=y,25=x    to 35=y,x=25
            Point a = new Point((int)(Scale * 10), (int)(Scale * 25));
            Point b = new Point((int)(Scale * 25), (int)(Scale * 25));
            Point c = new Point((int)(Scale * 25), (int)(Scale * 35));
            return new Point[] { a, b, c };
        }
        public static Point[] CToAltSwitchLine()
        {
            //45=y,10=x    to   45=y,25=x    to 35=y,25=x
            Point a = new Point((int)(Scale * 10), (int)(Scale * 45));
            Point b = new Point((int)(Scale * 25), (int)(Scale * 45));
            Point c = new Point((int)(Scale * 25), (int)(Scale * 35));
            return new Point[] { a, b, c };
        }
        public static Point[] AltSwitchToMainSwitchLine()
        {
            //35=y,25=x  to 35=y,x=45 to 25=y,x=45 to 25=y,x=60
            Point a = new Point((int)(Scale * 25), (int)(Scale * 35));
            Point b = new Point((int)(Scale * 45), (int)(Scale * 35));
            Point c = new Point((int)(Scale * 45), (int)(Scale * 25));
            Point d = new Point((int)(Scale * 60), (int)(Scale * 25));
            return new Point[] { a, b, c, d };
        }

        private static float Scale = 1;

        public static void DrawVisual(ref Image img, bool mainSwitch, bool altSwitch)
        {
            //50 is height of scale 1 image
            //60 is width of scale 1 image

            Scale = Math.Min((img.Height / 50), (img.Width / 60));

            //
            //   A       \
            //                 \
            //   B    \          Main
            //         Alt     /
            //   C    /

            //draw camera boxes


            Pen p = new Pen(Brushes.Black);
            Pen on = new Pen(Brushes.Red);
            

            Graphics g = Graphics.FromImage(img);
            g.FillRectangle(GetCameraBrush(mainSwitch,altSwitch,0), 0, 0, (Scale * 10), (Scale * 10));
            g.FillRectangle(GetCameraBrush(mainSwitch, altSwitch, 1), 0, Scale * 20, Scale * 10, Scale * 10);
            g.FillRectangle(GetCameraBrush(mainSwitch, altSwitch, 2), 0, Scale * 40, Scale * 10, Scale * 10);

            //draw lines
            //highlight lines which are active
            if (mainSwitch)
            {
                g.DrawLines(p, AltSwitchToMainSwitchLine());
                g.DrawLines(on, AToMainSwitchLine());
            }
            else
            {
                g.DrawLines(p, AToMainSwitchLine());
                g.DrawLines(on, AltSwitchToMainSwitchLine());
            }

            if (altSwitch)
            {
                g.DrawLines(p, CToAltSwitchLine());
                g.DrawLines(on, BToAltSwitchLine());
            }
            else
            {
                g.DrawLines(p, BToAltSwitchLine());
                g.DrawLines(on, CToAltSwitchLine());
            }

            g.Save();
        }

        private static Brush GetCameraBrush(bool mainSwitch, bool altSwitch, int cameraIndex)
        {
            Brush CamOn = Brushes.Green;
            Brush CamOff = Brushes.DarkGray;

            if (mainSwitch) {
                if (cameraIndex == 0) { return CamOn; }
            } else {
                if (altSwitch)
                {
                    if (cameraIndex == 1) { return CamOn; }
                }
                else {
                    if (cameraIndex == 2) { return CamOn; }
                }
            }
            return CamOff;
        }
    }
}
