﻿/*
 * Created by SharpDevelop.
 * User: David
 * Date: 3/8/2008
 * Time: 1:10 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace ODonel_Simple_ROV_Controller
{
	partial class MainForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.motorController = new System.Windows.Forms.TextBox();
            this.joystick = new System.Windows.Forms.TextBox();
            this.operate = new System.Windows.Forms.CheckBox();
            this.pololuPanel = new System.Windows.Forms.GroupBox();
            this.portBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.swayButtonNUD = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.sliderRadio = new System.Windows.Forms.RadioButton();
            this.axisRadio = new System.Windows.Forms.RadioButton();
            this.label4 = new System.Windows.Forms.Label();
            this.rawAxis = new System.Windows.Forms.TextBox();
            this.reverseZ = new System.Windows.Forms.CheckBox();
            this.reverseR = new System.Windows.Forms.CheckBox();
            this.reverseX = new System.Windows.Forms.CheckBox();
            this.reverseY = new System.Windows.Forms.CheckBox();
            this.joystickDetectionTimer = new System.Windows.Forms.Timer(this.components);
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cameraDiagram = new System.Windows.Forms.PictureBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorCheck = new System.Windows.Forms.Timer(this.components);
            this.cameraAngle1 = new ODonel_Simple_ROV_Controller.CameraAngle();
            this.pololuPanel.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.swayButtonNUD)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cameraDiagram)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.Timer1Tick);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(14, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Motor Controller:";
            // 
            // motorController
            // 
            this.motorController.BackColor = System.Drawing.Color.White;
            this.motorController.Location = new System.Drawing.Point(100, 14);
            this.motorController.Name = "motorController";
            this.motorController.ReadOnly = true;
            this.motorController.Size = new System.Drawing.Size(100, 20);
            this.motorController.TabIndex = 1;
            // 
            // joystick
            // 
            this.joystick.BackColor = System.Drawing.Color.White;
            this.joystick.Location = new System.Drawing.Point(100, 40);
            this.joystick.Name = "joystick";
            this.joystick.ReadOnly = true;
            this.joystick.Size = new System.Drawing.Size(100, 20);
            this.joystick.TabIndex = 2;
            // 
            // operate
            // 
            this.operate.Appearance = System.Windows.Forms.Appearance.Button;
            this.operate.BackColor = System.Drawing.SystemColors.ControlLight;
            this.operate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.operate.Location = new System.Drawing.Point(6, 19);
            this.operate.Name = "operate";
            this.operate.Size = new System.Drawing.Size(97, 98);
            this.operate.TabIndex = 7;
            this.operate.Text = "Operate";
            this.operate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.operate.UseVisualStyleBackColor = false;
            this.operate.CheckedChanged += new System.EventHandler(this.CheckBox1CheckedChanged);
            // 
            // pololuPanel
            // 
            this.pololuPanel.Controls.Add(this.portBox);
            this.pololuPanel.Controls.Add(this.label2);
            this.pololuPanel.Location = new System.Drawing.Point(12, 111);
            this.pololuPanel.Name = "pololuPanel";
            this.pololuPanel.Size = new System.Drawing.Size(200, 42);
            this.pololuPanel.TabIndex = 10;
            this.pololuPanel.TabStop = false;
            this.pololuPanel.Text = "Pololu";
            // 
            // portBox
            // 
            this.portBox.FormattingEnabled = true;
            this.portBox.Location = new System.Drawing.Point(73, 12);
            this.portBox.Name = "portBox";
            this.portBox.Size = new System.Drawing.Size(121, 21);
            this.portBox.TabIndex = 4;
            this.portBox.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(6, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 23);
            this.label2.TabIndex = 3;
            this.label2.Text = "COM Port:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.joystick);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.motorController);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(222, 93);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Status";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(129, 64);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "Reconnect";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(52, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 23);
            this.label3.TabIndex = 3;
            this.label3.Text = "Joystick:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.swayButtonNUD);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.sliderRadio);
            this.groupBox3.Controls.Add(this.axisRadio);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.rawAxis);
            this.groupBox3.Controls.Add(this.reverseZ);
            this.groupBox3.Controls.Add(this.reverseR);
            this.groupBox3.Controls.Add(this.reverseX);
            this.groupBox3.Controls.Add(this.reverseY);
            this.groupBox3.Location = new System.Drawing.Point(240, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(261, 183);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Joystick";
            // 
            // swayButtonNUD
            // 
            this.swayButtonNUD.Location = new System.Drawing.Point(215, 154);
            this.swayButtonNUD.Name = "swayButtonNUD";
            this.swayButtonNUD.Size = new System.Drawing.Size(40, 20);
            this.swayButtonNUD.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(112, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Sway Mode Button:";
            // 
            // sliderRadio
            // 
            this.sliderRadio.AutoSize = true;
            this.sliderRadio.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.sliderRadio.Location = new System.Drawing.Point(199, 134);
            this.sliderRadio.Name = "sliderRadio";
            this.sliderRadio.Size = new System.Drawing.Size(51, 17);
            this.sliderRadio.TabIndex = 14;
            this.sliderRadio.Text = "Slider";
            this.sliderRadio.UseVisualStyleBackColor = true;
            // 
            // axisRadio
            // 
            this.axisRadio.AutoSize = true;
            this.axisRadio.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.axisRadio.Checked = true;
            this.axisRadio.Location = new System.Drawing.Point(196, 111);
            this.axisRadio.Name = "axisRadio";
            this.axisRadio.Size = new System.Drawing.Size(54, 17);
            this.axisRadio.TabIndex = 13;
            this.axisRadio.TabStop = true;
            this.axisRadio.Text = "Z-Axis";
            this.axisRadio.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(112, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Vertical Control:";
            // 
            // rawAxis
            // 
            this.rawAxis.BackColor = System.Drawing.Color.White;
            this.rawAxis.Location = new System.Drawing.Point(6, 22);
            this.rawAxis.Multiline = true;
            this.rawAxis.Name = "rawAxis";
            this.rawAxis.ReadOnly = true;
            this.rawAxis.Size = new System.Drawing.Size(100, 152);
            this.rawAxis.TabIndex = 11;
            // 
            // reverseZ
            // 
            this.reverseZ.AutoSize = true;
            this.reverseZ.Location = new System.Drawing.Point(129, 91);
            this.reverseZ.Name = "reverseZ";
            this.reverseZ.Size = new System.Drawing.Size(129, 17);
            this.reverseZ.TabIndex = 10;
            this.reverseZ.Text = "Reverse Z Axis/Slider";
            this.reverseZ.UseVisualStyleBackColor = true;
            this.reverseZ.CheckedChanged += new System.EventHandler(this.reverseZ_CheckedChanged);
            // 
            // reverseR
            // 
            this.reverseR.AutoSize = true;
            this.reverseR.Location = new System.Drawing.Point(129, 68);
            this.reverseR.Name = "reverseR";
            this.reverseR.Size = new System.Drawing.Size(104, 17);
            this.reverseR.TabIndex = 9;
            this.reverseR.Text = "Reverse Rx Axis";
            this.reverseR.UseVisualStyleBackColor = true;
            this.reverseR.CheckedChanged += new System.EventHandler(this.reverseR_CheckedChanged);
            // 
            // reverseX
            // 
            this.reverseX.AutoSize = true;
            this.reverseX.Location = new System.Drawing.Point(129, 45);
            this.reverseX.Name = "reverseX";
            this.reverseX.Size = new System.Drawing.Size(98, 17);
            this.reverseX.TabIndex = 8;
            this.reverseX.Text = "Reverse X Axis";
            this.reverseX.UseVisualStyleBackColor = true;
            this.reverseX.CheckedChanged += new System.EventHandler(this.reverseX_CheckedChanged);
            // 
            // reverseY
            // 
            this.reverseY.AutoSize = true;
            this.reverseY.Location = new System.Drawing.Point(129, 22);
            this.reverseY.Name = "reverseY";
            this.reverseY.Size = new System.Drawing.Size(98, 17);
            this.reverseY.TabIndex = 7;
            this.reverseY.Text = "Reverse Y Axis";
            this.reverseY.UseVisualStyleBackColor = true;
            this.reverseY.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // joystickDetectionTimer
            // 
            this.joystickDetectionTimer.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.operate);
            this.groupBox4.Location = new System.Drawing.Point(387, 201);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(114, 123);
            this.groupBox4.TabIndex = 13;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Mission";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(41, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(23, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Off";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cameraDiagram
            // 
            this.cameraDiagram.BackColor = System.Drawing.Color.Transparent;
            this.cameraDiagram.Location = new System.Drawing.Point(6, 19);
            this.cameraDiagram.Name = "cameraDiagram";
            this.cameraDiagram.Size = new System.Drawing.Size(120, 101);
            this.cameraDiagram.TabIndex = 8;
            this.cameraDiagram.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.panel1);
            this.groupBox5.Controls.Add(this.cameraDiagram);
            this.groupBox5.Location = new System.Drawing.Point(12, 159);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(228, 123);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Camera";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.cameraAngle1);
            this.panel1.Location = new System.Drawing.Point(132, 17);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(87, 100);
            this.panel1.TabIndex = 9;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.tableLayoutPanel1);
            this.groupBox6.Location = new System.Drawing.Point(246, 201);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(130, 123);
            this.groupBox6.TabIndex = 14;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Thrusters";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 4;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(124, 104);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // errorProvider1
            // 
            this.errorProvider1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider1.ContainerControl = this;
            // 
            // errorCheck
            // 
            this.errorCheck.Tick += new System.EventHandler(this.errorCheck_Tick);
            // 
            // cameraAngle1
            // 
            this.cameraAngle1.Angle = 0;
            this.cameraAngle1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cameraAngle1.FlipGraph = false;
            this.cameraAngle1.Location = new System.Drawing.Point(0, 0);
            this.cameraAngle1.MaxAngle = 0;
            this.cameraAngle1.MinAngle = 0;
            this.cameraAngle1.Name = "cameraAngle1";
            this.cameraAngle1.Size = new System.Drawing.Size(87, 100);
            this.cameraAngle1.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 329);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.pololuPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Text = "O\'Donel ROV Controller";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainFormLoad);
            this.pololuPanel.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.swayButtonNUD)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cameraDiagram)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }
		private System.Windows.Forms.CheckBox operate;
        private System.Windows.Forms.TextBox joystick;
		private System.Windows.Forms.TextBox motorController;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Timer timer1;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.GroupBox pololuPanel;
        private System.Windows.Forms.ComboBox portBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox reverseZ;
        private System.Windows.Forms.CheckBox reverseR;
        private System.Windows.Forms.CheckBox reverseX;
        private System.Windows.Forms.CheckBox reverseY;
        private System.Windows.Forms.Timer joystickDetectionTimer;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox rawAxis;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.PictureBox cameraDiagram;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Timer errorCheck;
        private CameraAngle cameraAngle1;
        private System.Windows.Forms.RadioButton sliderRadio;
        private System.Windows.Forms.RadioButton axisRadio;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown swayButtonNUD;
        private System.Windows.Forms.Label label6;
    }
}
