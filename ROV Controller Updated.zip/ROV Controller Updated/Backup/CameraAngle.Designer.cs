﻿namespace ODonel_Simple_ROV_Controller
{
    partial class CameraAngle
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.angleBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.angleBox)).BeginInit();
            this.SuspendLayout();
            // 
            // angleBox
            // 
            this.angleBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.angleBox.Location = new System.Drawing.Point(0, 0);
            this.angleBox.Name = "angleBox";
            this.angleBox.Size = new System.Drawing.Size(50, 150);
            this.angleBox.TabIndex = 0;
            this.angleBox.TabStop = false;
            // 
            // CameraAngle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.angleBox);
            this.Name = "CameraAngle";
            this.Size = new System.Drawing.Size(50, 150);
            ((System.ComponentModel.ISupportInitialize)(this.angleBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox angleBox;
    }
}
