﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace ODonel_Simple_ROV_Controller
{
    public partial class PowerLevelBar : UserControl
    {
        public PowerLevelBar()
        {
            InitializeComponent();
        }

        private void PowerLevel_Load(object sender, EventArgs e)
        {

        }

        private int _powerLevel = 0;
        private const int MaxLevel = 1000;
        private const int MinLevel = -1000;

        public int PowerLevel
        {
            get { return _powerLevel; }
            set
            {
                _powerLevel = value;
                if (value > MaxLevel)
                {
                    _powerLevel = MaxLevel;
                }
                if (value < MinLevel)
                {
                    _powerLevel = MinLevel;
                }

                DrawBars();

            }

        }

        private void DrawBars()
        {

            Image bar = new Bitmap(powerBar.Width, powerBar.Height);
            Graphics g = Graphics.FromImage(bar);

            int mid = bar.Height / 2;

            //int powerVal = 0;
            //Brush col = Brushes.Black;

            if (PowerLevel > 96)
            {
                int powerVal = (int)((double)(bar.Height / 2.0) * ((double)PowerLevel / (double)MaxLevel));
                g.FillRectangle(Brushes.Green, 0, mid - powerVal, bar.Width, powerVal);
            }
            else
            {
                int powerVal = (int)((double)(bar.Height / 2.0) * ((double)PowerLevel / (double)MinLevel));
                g.FillRectangle(Brushes.Red, 0, mid, bar.Width, powerVal);
            }

            DrawBorder(bar, g);

            g.Save();
            powerBar.Image = bar;
        }

        private void DrawBorder(Image bar, Graphics g)
        {
            Pen border = new Pen(Brushes.Black);
            g.DrawRectangle(border, 1, 1, bar.Width - 3, bar.Height - 3);
        }






    }
}
