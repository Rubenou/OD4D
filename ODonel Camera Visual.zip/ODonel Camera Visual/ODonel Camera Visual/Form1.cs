﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Phidgets;
using Phidgets.Events;
using Renci.SshNet;
using AForge.Video;

namespace ODonel_Camera_Visual
{

    public partial class Form1 : Form
    {
        #region Declorations
        MJPEGStream stream1; //Enables Camera feed 1
        MJPEGStream stream2; //Enables Camera feed 2
        MJPEGStream stream3; //Enables Camera feed 3
        private InterfaceKit ifKit; //Creates Interface Kit object
        bool ifKit1;
        #endregion

        public Form1()
        {
            InitializeComponent();
            try
            {
                stream1 = new MJPEGStream("http://169.254.147.132:81/?action=stream"); //Camera feed 1 location
                stream1.NewFrame += stream1_newFrame;
                stream2 = new MJPEGStream("http://169.254.147.132:81/?action=stream"); //Camera feed 2 location
                stream2.NewFrame += stream2_newFrame;
                stream3 = new MJPEGStream("http://169.254.147.132:81/?action=stream"); //Camera feed 3 location
                stream3.NewFrame += stream3_newFrame;
            }
            catch
            {
                pictureBox1.Image = pictureBox1.ErrorImage;
                pictureBox2.Image = pictureBox2.ErrorImage;
                pictureBox3.Image = pictureBox3.ErrorImage;
            }
        }

        private void stream1_newFrame(object sender, NewFrameEventArgs eventArgs)
        {
            Bitmap bmp = (Bitmap)eventArgs.Frame.Clone();
            pictureBox1.Image = bmp; 
        }
        private void stream2_newFrame(object sender, NewFrameEventArgs eventArgs)
        {
            Bitmap bmp = (Bitmap)eventArgs.Frame.Clone();
            pictureBox2.Image = bmp;
        }
        private void stream3_newFrame(object sender, NewFrameEventArgs eventArgs)
        {
            Bitmap bmp = (Bitmap)eventArgs.Frame.Clone();
            pictureBox3.Image = bmp;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;

                ifKit = new InterfaceKit();
                ifKit.Attach += new AttachEventHandler(ifKit_Attach);
                ifKit.Detach += new DetachEventHandler(ifKit_Detach);
        }

        void ifKit_Attach(object sender, AttachEventArgs e)
        {
            ifKit1 = true;
        }

        private void ifKit_Detach(object sender, DetachEventArgs e)
        {
            ifKit1 = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(ifKit1 == true)
            {
                textBox1.Text = "Connected!";

            }
            else 
            {
                textBox1.Text = "Not Connected!";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //starts stream
            stream1.Start();
            stream2.Start();
            stream3.Start();
            System.Threading.Thread.Sleep(100);
            this.WindowState = FormWindowState.Maximized;
            label2.Text = "Live!";
            label2.ForeColor = Color.Green;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Stops stream
            stream1.Stop();
            stream2.Stop();
            stream3.Stop();
            label2.Text = "Not Live!";
            label2.ForeColor = Color.Red;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Stops stream
            stream1.Stop();
            stream2.Stop();
            stream3.Stop();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Enables Screen Pause Function
            if(stream1.IsRunning)
            {
                stream1.Stop();
            }
            else
            {
                stream1.Start();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //Enables Screen Pause Function
            if (stream2.IsRunning)
            {
                stream2.Stop();
            }
            else
            {
                stream2.Start();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            //Enables Screen Pause Function
            if (stream3.IsRunning)
            {
                stream3.Stop();
            }
            else
            {
                stream3.Start();
            }
        }
    }
}
